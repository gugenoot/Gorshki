namespace SmartWatering.Api.DTOs;

public class CreateDeviceDto
{
    public string Name { get; set; } = "";
    public string MacAddress { get; set; } = "";
    public string FirmwareVersion { get; set; } = "";
    public Guid PlantId { get; set; }
}