namespace SmartWatering.Api.DTOs;

public class TelemetryDto
{
    public Guid DeviceId { get; set; }

    public double SoilHumidity { get; set; }

    public double AirHumidity { get; set; }

    public double Temperature { get; set; }

    public bool WaterLevel { get; set; }
}