namespace SmartWatering.Api.DTOs;

public class LoginDto
{
    public string Login { get; set; } = "";

    public string Password { get; set; } = "";
}