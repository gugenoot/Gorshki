using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Data;
using SmartWatering.Api.Entities;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/watering")]
[Authorize]
public class WateringController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public WateringController(
        ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet("history")]
    public async Task<IActionResult> History()
    {
        return Ok(
            await _db.WateringEvents
                .OrderByDescending(x => x.StartTime)
                .ToListAsync());
    }

    [HttpPost("manual")]
    public async Task<IActionResult> Manual(Guid deviceId)
    {
        var evt = new WateringEvent
        {
            DeviceId = deviceId,
            StartTime = DateTime.UtcNow,
            DurationSeconds = 10,
            Reason = "Manual"
        };

        _db.WateringEvents.Add(evt);

        await _db.SaveChangesAsync();

        return Ok(evt);
    }
}