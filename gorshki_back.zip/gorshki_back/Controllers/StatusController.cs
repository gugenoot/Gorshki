using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Data;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/status")]
[Authorize]
public class StatusController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public StatusController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet("device/{deviceId}")]
    public async Task<IActionResult> GetDeviceStatus(Guid deviceId)
    {
        var device = await _db.Devices
            .Include(d => d.Plant)
            .FirstOrDefaultAsync(d => d.Id == deviceId);
        
        if (device == null)
            return NotFound();
        
        var lastReading = await _db.SensorReadings
            .Where(r => r.DeviceId == deviceId)
            .OrderByDescending(r => r.CreatedAt)
            .FirstOrDefaultAsync();
        
        // Последние 24 часа для графика
        var lastDayReadings = await _db.SensorReadings
            .Where(r => r.DeviceId == deviceId && r.CreatedAt >= DateTime.UtcNow.AddDays(-1))
            .OrderBy(r => r.CreatedAt)
            .ToListAsync();
        
        return Ok(new
        {
            device,
            lastReading,
            history = lastDayReadings,
            isOnline = device.Online && (DateTime.UtcNow - device.LastSeen).TotalMinutes < 5
        });
    }
}