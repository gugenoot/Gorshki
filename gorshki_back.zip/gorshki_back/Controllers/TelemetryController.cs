using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SmartWatering.Api.Data;
using SmartWatering.Api.DTOs;
using SmartWatering.Api.Entities;
using SmartWatering.Api.Hubs;
using SmartWatering.Api.Services;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/telemetry")]
public class TelemetryController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    private readonly WateringDecisionService _watering;

    private readonly IHubContext<TelemetryHub> _hub;

    public TelemetryController(
        ApplicationDbContext db,
        WateringDecisionService watering,
        IHubContext<TelemetryHub> hub)
    {
        _db = db;
        _watering = watering;
        _hub = hub;
    }

    [HttpPost]
    public async Task<IActionResult> Receive(
        TelemetryDto dto)
    {
        var reading = new SensorReading
        {
            DeviceId = dto.DeviceId,
            SoilHumidity = dto.SoilHumidity,
            AirHumidity = dto.AirHumidity,
            Temperature = dto.Temperature,
            WaterLevel = dto.WaterLevel
        };

        _db.SensorReadings.Add(reading);

        var shouldWater =
            _watering.ShouldWater(
                dto.SoilHumidity,
                dto.Temperature,
                dto.AirHumidity,
                dto.WaterLevel);

        await _db.SaveChangesAsync();

        await _hub.Clients.All.SendAsync(
            "telemetry",
            reading);

        return Ok(new
        {
            shouldWater,
            duration = 10
        });
    }
}