using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Data;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/alerts")]
[Authorize]
public class AlertsController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public AlertsController(
        ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(
            await _db.Alerts
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync());
    }

    [HttpPut("{id}/resolve")]
    public async Task<IActionResult> Resolve(Guid id)
    {
        var alert =
            await _db.Alerts.FindAsync(id);

        if (alert == null)
            return NotFound();

        alert.Resolved = true;

        await _db.SaveChangesAsync();

        return Ok();
    }
}