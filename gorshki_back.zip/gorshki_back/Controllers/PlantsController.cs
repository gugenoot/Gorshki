using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Data;
using SmartWatering.Api.Entities;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/plants")]
[Authorize]
public class PlantsController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public PlantsController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _db.Plants.ToListAsync());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var plant =
            await _db.Plants.FindAsync(id);

        if (plant == null)
            return NotFound();

        return Ok(plant);
    }

    [HttpPost]
    public async Task<IActionResult> Create(
        Plant plant)
    {
        _db.Plants.Add(plant);

        await _db.SaveChangesAsync();

        return Ok(plant);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(
        Guid id,
        Plant model)
    {
        var plant =
            await _db.Plants.FindAsync(id);

        if (plant == null)
            return NotFound();

        plant.Name = model.Name;
        plant.Species = model.Species;
        plant.SoilMin = model.SoilMin;
        plant.SoilMax = model.SoilMax;
        plant.TempMin = model.TempMin;
        plant.TempMax = model.TempMax;
        plant.AirHumidityMin = model.AirHumidityMin;
        plant.AirHumidityMax = model.AirHumidityMax;

        await _db.SaveChangesAsync();

        return Ok(plant);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var plant =
            await _db.Plants.FindAsync(id);

        if (plant == null)
            return NotFound();

        _db.Plants.Remove(plant);

        await _db.SaveChangesAsync();

        return NoContent();
    }
}