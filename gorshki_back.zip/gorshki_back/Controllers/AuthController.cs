using Microsoft.AspNetCore.Mvc;
using SmartWatering.Api.Data;
using SmartWatering.Api.DTOs;
using SmartWatering.Api.Entities;
using SmartWatering.Api.Services;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly ApplicationDbContext _db;
    private readonly JwtService _jwt;

    public AuthController(
        ApplicationDbContext db,
        JwtService jwt)
    {
        _db = db;
        _jwt = jwt;
    }

    [HttpPost("register")]
    public IActionResult Register(RegisterDto dto)
    {
        var user = new User
        {
            Login = dto.Login,
            PasswordHash =
                BCrypt.Net.BCrypt.HashPassword(dto.Password)
        };

        _db.Users.Add(user);

        _db.SaveChanges();

        return Ok();
    }

    [HttpPost("login")]
    public IActionResult Login(LoginDto dto)
    {
        var user =
            _db.Users.FirstOrDefault(
                x => x.Login == dto.Login);

        if (user == null)
            return Unauthorized();

        if (!BCrypt.Net.BCrypt.Verify(
                dto.Password,
                user.PasswordHash))
            return Unauthorized();

        return Ok(new
        {
            token = _jwt.Generate(user.Login)
        });
    }
}