using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Data;
using SmartWatering.Api.DTOs;
using SmartWatering.Api.Entities;

namespace SmartWatering.Api.Controllers;

[ApiController]
[Route("api/devices")]
[Authorize]
public class DevicesController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public DevicesController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var devices = await _db.Devices
            .Include(x => x.Plant)
            .ToListAsync();

        return Ok(devices);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var device = await _db.Devices
            .Include(x => x.Plant)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (device == null)
            return NotFound();

        return Ok(device);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateDeviceDto dto)
    {
        // Проверяем, существует ли растение
        var plant = await _db.Plants.FindAsync(dto.PlantId);
        if (plant == null)
        {
            return BadRequest($"Растение с ID {dto.PlantId} не найдено");
        }

        var device = new Device
        {
            Id = Guid.NewGuid(),
            Name = dto.Name,
            MacAddress = dto.MacAddress,
            FirmwareVersion = dto.FirmwareVersion,
            PlantId = dto.PlantId,
            Online = false,
            LastSeen = DateTime.UtcNow
        };

        _db.Devices.Add(device);
        await _db.SaveChangesAsync();

        // Загружаем растение для ответа
        device.Plant = plant;

        return Ok(device);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(Guid id, Device model)
    {
        var device = await _db.Devices.FindAsync(id);

        if (device == null)
            return NotFound();

        device.Name = model.Name;
        device.FirmwareVersion = model.FirmwareVersion;
        device.MacAddress = model.MacAddress;

        await _db.SaveChangesAsync();

        return Ok(device);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var device = await _db.Devices.FindAsync(id);

        if (device == null)
            return NotFound();

        _db.Devices.Remove(device);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}