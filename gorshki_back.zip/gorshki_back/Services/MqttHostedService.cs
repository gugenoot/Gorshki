using MQTTnet;
using MQTTnet.Client;
using System.Text.Json;
using SmartWatering.Api.DTOs;
using Microsoft.Extensions.DependencyInjection;
using SmartWatering.Api.Data;
using SmartWatering.Api.Entities;
using Microsoft.AspNetCore.SignalR;
using SmartWatering.Api.Hubs;
using System.Text;

namespace SmartWatering.Api.Services;

public class MqttHostedService : IHostedService
{
    private IMqttClient? _mqttClient;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IHubContext<TelemetryHub> _hubContext;
    private readonly ILogger<MqttHostedService> _logger;
    private readonly IConfiguration _configuration;

    public MqttHostedService(
        IServiceScopeFactory scopeFactory,
        IHubContext<TelemetryHub> hubContext,
        ILogger<MqttHostedService> logger,
        IConfiguration configuration)
    {
        _scopeFactory = scopeFactory;
        _hubContext = hubContext;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        // Получаем настройки брокера из конфигурации
        var mqttBroker = _configuration["Mqtt:Broker"] ?? "broker.emqx.io";
        var mqttPort = int.Parse(_configuration["Mqtt:Port"] ?? "1883");
        
        var factory = new MqttFactory();
        _mqttClient = factory.CreateMqttClient();
        
        // Настройка подключения к облачному брокеру
        var options = new MqttClientOptionsBuilder()
            .WithTcpServer(mqttBroker, mqttPort)
            .WithClientId($"backend_smartwatering_{Guid.NewGuid()}")
            .WithCleanSession()
            .WithKeepAlivePeriod(TimeSpan.FromSeconds(60))
            .Build();
        
        _mqttClient.ConnectedAsync += OnConnected;
        _mqttClient.DisconnectedAsync += OnDisconnected;
        _mqttClient.ApplicationMessageReceivedAsync += OnMessageReceived;
        
        try
        {
            await _mqttClient.ConnectAsync(options, cancellationToken);
            _logger.LogInformation($"MQTT Client connecting to {mqttBroker}:{mqttPort}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to connect to MQTT broker");
        }
    }
    
    private async Task OnConnected(MqttClientConnectedEventArgs e)
    {
        _logger.LogInformation("MQTT Client connected to cloud broker");
        
        // Подписываемся на все топики телеметрии
        var subscribeOptions = new MqttClientSubscribeOptionsBuilder()
            .WithTopicFilter("telemetry/#", MQTTnet.Protocol.MqttQualityOfServiceLevel.AtLeastOnce)
            .Build();
        
        await _mqttClient!.SubscribeAsync(subscribeOptions);
        _logger.LogInformation($"Subscribed to telemetry/#");
    }
    
    private async Task OnDisconnected(MqttClientDisconnectedEventArgs e)
    {
        _logger.LogWarning($"MQTT Client disconnected. Reason: {e.Reason}");
        
        await Task.Delay(5000);
        
        if (_mqttClient != null && !_mqttClient.IsConnected)
        {
            try
            {
                var options = new MqttClientOptionsBuilder()
                    .WithTcpServer(_configuration["Mqtt:Broker"] ?? "broker.emqx.io", int.Parse(_configuration["Mqtt:Port"] ?? "1883"))
                    .WithClientId($"backend_smartwatering_{Guid.NewGuid()}")
                    .WithCleanSession()
                    .Build();
                
                await _mqttClient.ConnectAsync(options);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to reconnect to MQTT broker");
            }
        }
    }
    
    private async Task OnMessageReceived(MqttApplicationMessageReceivedEventArgs args)
    {
        var topic = args.ApplicationMessage.Topic;
        
        // используем встроенный метод расширения
        var message = args.ApplicationMessage.ConvertPayloadToString();
        
        _logger.LogInformation($"MQTT message on {topic}: {message}");
        
        // Обрабатываем только топики телеметрии
        if (topic != null && topic.StartsWith("telemetry/"))
        {
            var deviceIdStr = topic.Replace("telemetry/", "");
            if (Guid.TryParse(deviceIdStr, out var deviceId))
            {
                try
                {
                    var telemetry = JsonSerializer.Deserialize<TelemetryDto>(message);
                    if (telemetry != null)
                    {
                        telemetry.DeviceId = deviceId;
                        await ProcessTelemetry(telemetry);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to process MQTT message");
                }
            }
        }
    }
    
    private async Task ProcessTelemetry(TelemetryDto dto)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var wateringService = scope.ServiceProvider.GetRequiredService<WateringDecisionService>();
        
        var reading = new SensorReading
        {
            DeviceId = dto.DeviceId,
            SoilHumidity = dto.SoilHumidity,
            AirHumidity = dto.AirHumidity,
            Temperature = dto.Temperature,
            WaterLevel = dto.WaterLevel,
            CreatedAt = DateTime.UtcNow
        };
        
        db.SensorReadings.Add(reading);
        
        // Обновляем статус устройства
        var device = await db.Devices.FindAsync(dto.DeviceId);
        if (device != null)
        {
            device.LastSeen = DateTime.UtcNow;
            device.Online = true;
        }
        
        var shouldWater = wateringService.ShouldWater(
            dto.SoilHumidity,
            dto.Temperature,
            dto.AirHumidity,
            dto.WaterLevel);
        
        await db.SaveChangesAsync();
        
        // Отправляем real-time обновление через SignalR
        await _hubContext.Clients.All.SendAsync("TelemetryReceived", new
        {
            reading,
            shouldWater
        });
        
        // Если нужно полить - отправляем команду обратно через MQTT
        if (shouldWater && device != null)
        {
            await SendWateringCommand(device.Id.ToString());
        }
    }
    
    private async Task SendWateringCommand(string deviceId)
    {
        if (_mqttClient != null && _mqttClient.IsConnected)
        {
            var message = new MqttApplicationMessageBuilder()
                .WithTopic($"command/{deviceId}/water")
                .WithPayload("{\"action\":\"water\",\"duration\":10}")
                .WithQualityOfServiceLevel(MQTTnet.Protocol.MqttQualityOfServiceLevel.AtLeastOnce)
                .Build();
            
            await _mqttClient.PublishAsync(message);
            _logger.LogInformation($"Sent watering command to device {deviceId}");
        }
        else
        {
            _logger.LogWarning($"Cannot send command - MQTT client not connected");
        }
    }
    
    public async Task StopAsync(CancellationToken cancellationToken)
    {
        if (_mqttClient != null)
        {
            await _mqttClient.DisconnectAsync();
            _mqttClient.Dispose();
            _logger.LogInformation("MQTT Client stopped");
        }
    }
}