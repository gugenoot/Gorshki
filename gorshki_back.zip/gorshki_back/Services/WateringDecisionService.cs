namespace SmartWatering.Api.Services;

public class WateringDecisionService
{
    public bool ShouldWater(
        double soil,
        double temperature,
        double airHumidity,
        bool waterLevel)
    {
        return soil < 30
               && waterLevel
               && temperature >= 18
               && temperature <= 28
               && airHumidity >= 40
               && airHumidity <= 70;
    }
}