using Microsoft.AspNetCore.SignalR;

namespace SmartWatering.Api.Hubs;

public class TelemetryHub : Hub
{
}