using Microsoft.EntityFrameworkCore;
using SmartWatering.Api.Entities;

namespace SmartWatering.Api.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(
        DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();

    public DbSet<Device> Devices => Set<Device>();

    public DbSet<Plant> Plants => Set<Plant>();

    public DbSet<SensorReading> SensorReadings => Set<SensorReading>();

    public DbSet<WateringEvent> WateringEvents => Set<WateringEvent>();

    public DbSet<Alert> Alerts => Set<Alert>();
}