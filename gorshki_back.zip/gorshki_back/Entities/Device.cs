namespace SmartWatering.Api.Entities;

public class Device
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public string MacAddress { get; set; } = "";

    public string FirmwareVersion { get; set; } = "";

    public bool Online { get; set; }

    public DateTime LastSeen { get; set; }

    public Guid PlantId { get; set; }

    public Plant Plant { get; set; } = null!;

    public ICollection<SensorReading>? Readings { get; set; }
}