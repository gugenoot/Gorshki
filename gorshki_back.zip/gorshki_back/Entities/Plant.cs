namespace SmartWatering.Api.Entities;

public class Plant
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public string Species { get; set; } = "";

    public double SoilMin { get; set; }

    public double SoilMax { get; set; }

    public double TempMin { get; set; }

    public double TempMax { get; set; }

    public double AirHumidityMin { get; set; }

    public double AirHumidityMax { get; set; }

    public ICollection<Device>? Devices { get; set; }
}