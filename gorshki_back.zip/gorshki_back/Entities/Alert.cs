namespace SmartWatering.Api.Entities;

public class Alert
{
    public Guid Id { get; set; }

    public Guid DeviceId { get; set; }

    public string Type { get; set; } = "";

    public string Message { get; set; } = "";

    public bool Resolved { get; set; }

    public DateTime CreatedAt { get; set; } =
        DateTime.UtcNow;
}