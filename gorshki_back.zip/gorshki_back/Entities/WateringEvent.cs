namespace SmartWatering.Api.Entities;

public class WateringEvent
{
    public Guid Id { get; set; }

    public Guid DeviceId { get; set; }

    public Device Device { get; set; } = null!;

    public DateTime StartTime { get; set; }

    public int DurationSeconds { get; set; }

    public string Reason { get; set; } = "";
}