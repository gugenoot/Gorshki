namespace SmartWatering.Api.Entities;

public class SensorReading
{
    public Guid Id { get; set; }

    public Guid DeviceId { get; set; }

    public Device Device { get; set; } = null!;

    public double SoilHumidity { get; set; }

    public double AirHumidity { get; set; }

    public double Temperature { get; set; }

    public bool WaterLevel { get; set; }

    public DateTime CreatedAt { get; set; } =
        DateTime.UtcNow;
}