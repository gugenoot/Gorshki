import React, { useState } from 'react';
import type { Device, SensorReading } from '../types';
import { Thermometer, Droplets, Wind, Battery, Activity, Calendar, Power } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DeviceCardProps {
  device: Device;
  lastReading: SensorReading | null;
  history: SensorReading[];
  onManualWater: () => void;
}

export const DeviceCard: React.FC<DeviceCardProps> = ({ device, lastReading, history, onManualWater }) => {
  const [showHistory, setShowHistory] = useState(false);
  
  const isOnline = device.online && (new Date().getTime() - new Date(device.lastSeen).getTime()) < 5 * 60 * 1000;

  const getSoilStatus = (value: number) => {
    if (!device.plant) return 'normal';
    if (value < device.plant.soilMin) return 'danger';
    if (value > device.plant.soilMax) return 'warning';
    return 'normal';
  };

  const getTempStatus = (value: number) => {
    if (!device.plant) return 'normal';
    if (value < device.plant.tempMin || value > device.plant.tempMax) return 'danger';
    return 'normal';
  };

  const chartData = history.map(h => ({
    time: new Date(h.createdAt).toLocaleTimeString(),
    soil: h.soilHumidity,
    temp: h.temperature,
    airHum: h.airHumidity,
  }));

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden shadow-xl">
      {/* Header */}
      <div className="bg-gray-800/50 p-4 border-b border-gray-700">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-white">{device.name}</h2>
            <p className="text-sm text-gray-400">
              {device.plant?.name || 'Растение не выбрано'} • {device.firmwareVersion}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs ${
              isOnline ? 'bg-green-900 text-green-300' : 'bg-gray-700 text-gray-400'
            }`}>
              <Power size={12} />
              <span>{isOnline ? 'Online' : 'Offline'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Current Readings */}
      {lastReading ? (
        <div className="p-4 grid grid-cols-2 gap-4">
          <div className="bg-gray-700/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Влажность почвы</span>
              <Droplets size={16} className="text-blue-400" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white">{lastReading.soilHumidity}%</span>
              <span className={`text-xs px-2 py-1 rounded-full ${
                getSoilStatus(lastReading.soilHumidity) === 'danger' ? 'bg-red-900 text-red-300' :
                getSoilStatus(lastReading.soilHumidity) === 'warning' ? 'bg-yellow-900 text-yellow-300' :
                'bg-green-900 text-green-300'
              }`}>
                {getSoilStatus(lastReading.soilHumidity) === 'danger' ? 'Сухо' :
                 getSoilStatus(lastReading.soilHumidity) === 'warning' ? 'Переувлажнено' : 'Норма'}
              </span>
            </div>
            {device.plant && (
              <div className="mt-1 text-xs text-gray-500">
                Норма: {device.plant.soilMin}% - {device.plant.soilMax}%
              </div>
            )}
          </div>

          <div className="bg-gray-700/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Температура</span>
              <Thermometer size={16} className="text-red-400" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white">{lastReading.temperature}°C</span>
              <span className={`text-xs px-2 py-1 rounded-full ${
                getTempStatus(lastReading.temperature) === 'danger' ? 'bg-red-900 text-red-300' : 'bg-green-900 text-green-300'
              }`}>
                {getTempStatus(lastReading.temperature) === 'danger' ? 'Критично' : 'Норма'}
              </span>
            </div>
            {device.plant && (
              <div className="mt-1 text-xs text-gray-500">
                Норма: {device.plant.tempMin}°C - {device.plant.tempMax}°C
              </div>
            )}
          </div>

          <div className="bg-gray-700/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Влажность воздуха</span>
              <Wind size={16} className="text-cyan-400" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white">{lastReading.airHumidity}%</span>
            </div>
            {device.plant && (
              <div className="mt-1 text-xs text-gray-500">
                Норма: {device.plant.airHumidityMin}% - {device.plant.airHumidityMax}%
              </div>
            )}
          </div>

          <div className="bg-gray-700/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Уровень воды</span>
              <Battery size={16} className="text-green-400" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white">{lastReading.waterLevel ? 'Есть' : 'Нет'}</span>
              <span className={`text-xs px-2 py-1 rounded-full ${
                lastReading.waterLevel ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'
              }`}>
                {lastReading.waterLevel ? 'Достаточно' : 'Требуется долить'}
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-gray-500">
          Нет данных с устройства
        </div>
      )}

      {/* Actions */}
      <div className="p-4 border-t border-gray-700 flex justify-between">
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
        >
          <Activity size={18} />
          <span>{showHistory ? 'Скрыть историю' : 'Показать историю'}</span>
        </button>
        <button
          onClick={onManualWater}
          disabled={!lastReading?.waterLevel}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
            lastReading?.waterLevel
              ? 'bg-blue-600 hover:bg-blue-500 text-white'
              : 'bg-gray-700 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Droplets size={18} />
          <span>Ручной полив</span>
        </button>
      </div>

      {/* History Chart */}
      {showHistory && history.length > 0 && (
        <div className="p-4 border-t border-gray-700 bg-gray-800/30">
          <div className="flex items-center space-x-2 mb-4">
            <Calendar size={16} className="text-gray-400" />
            <span className="text-sm text-gray-400">История за последние 24 часа</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" fontSize={10} />
                <YAxis stroke="#9CA3AF" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }}
                  labelStyle={{ color: '#9CA3AF' }}
                />
                <Line type="monotone" dataKey="soil" stroke="#60A5FA" name="Влажность почвы (%)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="temp" stroke="#F87171" name="Температура (°C)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="airHum" stroke="#34D399" name="Влажность воздуха (%)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};