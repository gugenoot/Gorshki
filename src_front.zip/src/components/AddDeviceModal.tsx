import React, { useState, useEffect } from 'react';
import { devices, plants } from '../api/client';
import type { Plant } from '../types';
import { X } from 'lucide-react';

interface AddDeviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeviceAdded: () => void;
}

export const AddDeviceModal: React.FC<AddDeviceModalProps> = ({ isOpen, onClose, onDeviceAdded }) => {
  const [plantList, setPlantList] = useState<Plant[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    macAddress: '',
    firmwareVersion: '1.0.0',
    plantId: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadPlants();
    }
  }, [isOpen]);

  const loadPlants = async () => {
    try {
      const response = await plants.getAll();
      setPlantList(response.data);
      if (response.data.length > 0) {
        setFormData(prev => ({ ...prev, plantId: response.data[0].id }));
      } else {
        setError('Нет растений. Сначала добавьте растение');
      }
    } catch (err) {
      console.error('Failed to load plants', err);
      setError('Ошибка загрузки растений');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const deviceData = {
        name: formData.name,
        macAddress: formData.macAddress,
        firmwareVersion: formData.firmwareVersion,
        plantId: formData.plantId
      };
      
      console.log('Sending device data:', deviceData);
      
      const response = await devices.create(deviceData);
      console.log('Device created:', response.data);
      
      onDeviceAdded();
      onClose();
      // Сброс формы
      setFormData({ 
        name: '', 
        macAddress: '', 
        firmwareVersion: '1.0.0', 
        plantId: plantList[0]?.id || '' 
      });
    } catch (err: any) {
      console.error('Failed to create device', err);
      if (err.response?.data?.title) {
        setError(err.response.data.title);
      } else if (err.response?.data) {
        setError(JSON.stringify(err.response.data));
      } else {
        setError('Ошибка при создании устройства');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-xl w-full max-w-md p-6 border border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Добавить устройство</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {error && (
          <div className="mb-4 bg-red-900/50 text-red-300 p-3 rounded-lg text-sm whitespace-pre-wrap">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Название устройства *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-green-500"
              required
              placeholder="Например: Мой горшок"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              MAC-адрес *
            </label>
            <input
              type="text"
              value={formData.macAddress}
              onChange={(e) => setFormData({ ...formData, macAddress: e.target.value })}
              placeholder="AA:BB:CC:DD:EE:FF"
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-green-500"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Формат: XX:XX:XX:XX:XX:XX</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Версия прошивки
            </label>
            <input
              type="text"
              value={formData.firmwareVersion}
              onChange={(e) => setFormData({ ...formData, firmwareVersion: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-green-500"
              placeholder="1.0.0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Растение *
            </label>
            <select
              value={formData.plantId}
              onChange={(e) => setFormData({ ...formData, plantId: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-green-500"
              required
            >
              {plantList.length === 0 ? (
                <option value="">Нет растений - сначала добавьте растение</option>
              ) : (
                plantList.map(plant => (
                  <option key={plant.id} value={plant.id}>
                    {plant.name} ({plant.species})
                  </option>
                ))
              )}
            </select>
          </div>

          <button
            type="submit"
            disabled={loading || plantList.length === 0}
            className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Добавление...' : 'Добавить устройство'}
          </button>
        </form>
      </div>
    </div>
  );
};