import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSignalR } from '../hooks/useSignalR';
import { devices, status, watering } from '../api/client';
import type { Device, SensorReading } from '../types';
import { DeviceCard } from '../components/DeviceCard.tsx';
import { Plus, Droplets } from 'lucide-react';
import { AddDeviceModal } from '../components/AddDeviceModal.tsx';

export const Dashboard: React.FC = () => {
  const { logout } = useAuth();
  const [deviceList, setDeviceList] = useState<Device[]>([]);
  const [deviceStatuses, setDeviceStatuses] = useState<Map<string, { reading: SensorReading | null; history: SensorReading[] }>>(new Map());
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const onTelemetryReceived = (data: any) => {
    console.log('New telemetry:', data);
    loadDeviceStatuses();
  };

  const { isConnected } = useSignalR(onTelemetryReceived);

  const loadDevices = async () => {
    const response = await devices.getAll();
    setDeviceList(response.data);
    return response.data;
  };

  const loadDeviceStatuses = async () => {
    const currentDevices = deviceList.length ? deviceList : await loadDevices();
    
    const statuses = new Map();
    for (const device of currentDevices) {
      try {
        const response = await status.getDevice(device.id);
        statuses.set(device.id, {
          reading: response.data.lastReading,
          history: response.data.history,
        });
      } catch (err) {
        console.error(`Failed to load status for device ${device.id}`, err);
      }
    }
    setDeviceStatuses(statuses);
    setLoading(false);
  };

  useEffect(() => {
    loadDevices();
    loadDeviceStatuses();
    
    const interval = setInterval(loadDeviceStatuses, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleManualWatering = async (deviceId: string) => {
    try {
      await watering.manual(deviceId);
      alert('Полив запущен');
    } catch (err) {
      console.error('Failed to start watering', err);
      alert('Ошибка при запуске полива');
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <nav className="bg-gray-800 border-b border-gray-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-3">
              <Droplets className="text-green-500" size={28} />
              <span className="text-xl font-bold text-white">Smart Watering</span>
              {isConnected ? (
                <span className="text-xs bg-green-900 text-green-300 px-2 py-1 rounded-full">
                  ● Real-time
                </span>
              ) : (
                <span className="text-xs bg-gray-700 text-gray-400 px-2 py-1 rounded-full">
                  ○ Offline
                </span>
              )}
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-500 px-4 py-2 rounded-lg transition-colors"
              >
                <Plus size={18} />
                <span>Добавить устройство</span>
              </button>
              <button
                onClick={logout}
                className="text-gray-300 hover:text-white transition-colors"
              >
                Выйти
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
          </div>
        ) : deviceList.length === 0 ? (
          <div className="text-center py-16">
            <Droplets size={64} className="mx-auto text-gray-600 mb-4" />
            <h2 className="text-2xl font-semibold text-gray-400 mb-2">Нет устройств</h2>
            <p className="text-gray-500 mb-4">Добавьте вашу систему автополива</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-green-600 hover:bg-green-500 px-6 py-2 rounded-lg transition-colors"
            >
              Добавить устройство
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {deviceList.map((device) => {
              const status = deviceStatuses.get(device.id);
              return (
                <DeviceCard
                  key={device.id}
                  device={device}
                  lastReading={status?.reading || null}
                  history={status?.history || []}
                  onManualWater={() => handleManualWatering(device.id)}
                />
              );
            })}
          </div>
        )}
      </main>

      <AddDeviceModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onDeviceAdded={() => {
          loadDevices();
          loadDeviceStatuses();
        }}
      />
    </div>
  );
};