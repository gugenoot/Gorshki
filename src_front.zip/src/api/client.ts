import axios from 'axios';
import type { Device, Plant, SensorReading, WateringEvent, Alert } from '../types';

const API_URL = 'http://localhost:5201/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  register: async (login: string, password: string) => {
    return await api.post('/auth/register', { login, password });
  },
  login: async (login: string, password: string) => {
    return await api.post('/auth/login', { login, password });
  },
};

export const devices = {
  getAll: () => api.get<Device[]>('/devices'),
  get: (id: string) => api.get<Device>(`/devices/${id}`),
  create: (device: { name: string; macAddress: string; firmwareVersion: string; plantId: string }) => 
    api.post('/devices', device),
  update: (id: string, device: Partial<Device>) => api.put(`/devices/${id}`, device),
  delete: (id: string) => api.delete(`/devices/${id}`),
};

export const plants = {
  getAll: () => api.get<Plant[]>('/plants'),
  get: (id: string) => api.get<Plant>(`/plants/${id}`),
  create: (plant: Partial<Plant>) => api.post('/plants', plant),
  update: (id: string, plant: Partial<Plant>) => api.put(`/plants/${id}`, plant),
  delete: (id: string) => api.delete(`/plants/${id}`),
};

export const telemetry = {
  getHistory: (deviceId: string) => 
    api.get<SensorReading[]>(`/telemetry/history/${deviceId}`),
  getLatest: (deviceId: string) =>
    api.get<SensorReading>(`/telemetry/latest/${deviceId}`),
};

export const watering = {
  getHistory: () => api.get<WateringEvent[]>('/watering/history'),
  manual: (deviceId: string) => api.post(`/watering/manual?deviceId=${deviceId}`),
};

export const alerts = {
  getAll: () => api.get<Alert[]>('/alerts'),
  resolve: (id: string) => api.put(`/alerts/${id}/resolve`),
};

export const status = {
  getDevice: (deviceId: string) => api.get(`/status/device/${deviceId}`),
};

export default api;