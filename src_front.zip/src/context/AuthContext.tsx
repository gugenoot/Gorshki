import React, { createContext, useContext, useState } from 'react';
import axios from 'axios';

interface AuthContextType {
  token: string | null;
  login: (username: string, userPassword: string) => Promise<void>;
  register: (username: string, userPassword: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));

  const loginUser = async (username: string, userPassword: string) => {
    try {
      const response = await axios.post('http://localhost:5201/api/auth/login', {
        login: username,
        password: userPassword
      });
      const newToken = response.data.token;
      localStorage.setItem('token', newToken);
      setToken(newToken);
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Ошибка входа');
    }
  };

  const registerUser = async (username: string, userPassword: string) => {
    try {
      await axios.post('http://localhost:5201/api/auth/register', {
        login: username,
        password: userPassword
      });
      await loginUser(username, userPassword);
    } catch (error) {
      console.error('Register error:', error);
      throw new Error('Ошибка регистрации');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
  };

  return (
    <AuthContext.Provider value={{ 
      token, 
      login: loginUser, 
      register: registerUser, 
      logout, 
      isAuthenticated: !!token 
    }}>
      {children}
    </AuthContext.Provider>
  );
};