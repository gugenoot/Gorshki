export interface User {
  id: string;
  login: string;
  role: string;
}

export interface Plant {
  id: string;
  name: string;
  species: string;
  soilMin: number;
  soilMax: number;
  tempMin: number;
  tempMax: number;
  airHumidityMin: number;
  airHumidityMax: number;
}

export interface Device {
  id: string;
  name: string;
  macAddress: string;
  firmwareVersion: string;
  online: boolean;
  lastSeen: string;
  plantId: string;
  plant?: Plant;
}

export interface SensorReading {
  id: string;
  deviceId: string;
  soilHumidity: number;
  airHumidity: number;
  temperature: number;
  waterLevel: boolean;
  createdAt: string;
}

export interface WateringEvent {
  id: string;
  deviceId: string;
  startTime: string;
  durationSeconds: number;
  reason: string;
}

export interface Alert {
  id: string;
  deviceId: string;
  type: string;
  message: string;
  resolved: boolean;
  createdAt: string;
}