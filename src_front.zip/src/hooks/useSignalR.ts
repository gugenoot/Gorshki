import { useEffect, useState } from 'react';
import { HubConnection, HubConnectionBuilder } from '@microsoft/signalr';

export const useSignalR = (onTelemetryReceived?: (data: any) => void) => {
  const [connection, setConnection] = useState<HubConnection | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const newConnection = new HubConnectionBuilder()
      .withUrl('http://localhost:5201/telemetryHub')
      .withAutomaticReconnect()
      .build();

    newConnection.start()
      .then(() => {
        console.log('SignalR connected');
        setIsConnected(true);
        setConnection(newConnection);
      })
      .catch(err => console.error('SignalR connection error:', err));

    if (onTelemetryReceived) {
      newConnection.on('TelemetryReceived', onTelemetryReceived);
    }

    return () => {
      newConnection.stop();
    };
  }, []);

  return { connection, isConnected };
};